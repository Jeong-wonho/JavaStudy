package com.day;

public interface I {
	String getattr();
}
